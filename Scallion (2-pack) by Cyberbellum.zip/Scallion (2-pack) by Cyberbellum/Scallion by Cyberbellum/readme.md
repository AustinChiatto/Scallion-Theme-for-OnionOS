# `Scallion` *by* `Cyberbellum`

*Alternate version of my minimalist theme `Shallot`.*

## Credits

Custom made icons by Aemiii91:
`cps3`, `gw`, `pico`, `poke`, `ports`, `satella`, `scummvm`, `search`, `sufami`, and `tic`.

**Custom `nds` icon:**  
by <u>Equinox</u> (RGH discord)

**Background removal:**  
[u/kiefeater](https://www.reddit.com/r/MiyooMini/comments/1czvnqz/true_png_images_of_analogue_icons_by/) removed the black background from all console icons, making them compatible with other themes!

**Icon Color Changes:** 
Made by Cyberbellum

**Console icons:** Analogue openFPGA Platform Art Set by spiritualized1997  
https://github.com/spiritualized1997/openFPGA-Platform-Art-Set
